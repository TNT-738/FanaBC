package com.news.fanabc.Utils;

import java.util.ArrayList;

import static com.news.fanabc.Utils.UrlType.BUSINESS;
import static com.news.fanabc.Utils.UrlType.HEALTH;
import static com.news.fanabc.Utils.UrlType.NEWS;
import static com.news.fanabc.Utils.UrlType.SPORT;
import static com.news.fanabc.Utils.UrlType.TECH;
import static com.news.fanabc.Utils.UrlType.VIDEO;
import static com.news.fanabc.Utils.UrlType.WORLD;

public class Lang_Type {

    private LangCode langCode;

    private UrlType homeUrl;
    private UrlType ethiopia_news;
    private UrlType bussiness;
    private UrlType sport;
    private UrlType worldNews;
    private UrlType tech;
    private UrlType video;
    private UrlType health;

    private ArrayList<UrlType> allUrl;

    public ArrayList<UrlType> getAllUrl() {
        return allUrl;
    }

    public enum LangCode {
        Amharic {
            public String toString() {
                return "";
            }
        }, English {
            public String toString() {
                return "english";
            }
        }, AfanOromo {
            public String toString() {
                return "afanoromo";
            }
        }, Tigrigna {
            public String toString() {
                return "tigrigna";
            }
        }
    }

    public Lang_Type(LangCode langCode) {
        this.langCode = langCode;
        allUrl = new ArrayList<>(getLanguageUrl(this.langCode));
    }

    public String getLanguage(LangCode langCode) {

        return langCode.toString();
    }


    public ArrayList<UrlType> getLanguageUrl(LangCode langCode) {
        String Language = getLanguage(langCode);
        String mainUrl = "https://fanabc.com/";

        ArrayList<UrlType> languageUrl = new ArrayList<>();
        switch (langCode) {

            case Amharic:
                languageUrl.clear();
                homeUrl = new UrlType(mainUrl + Language, UrlType.HOME);
                ethiopia_news = new UrlType(mainUrl + Language + "/category/localnews/", NEWS);
                bussiness = new UrlType(mainUrl + Language + "/category/buz/", BUSINESS);
                sport = new UrlType(mainUrl + Language + "/category/%e1%88%b5%e1%8d%93%e1%88%ad%e1%89%b5/", SPORT);
                worldNews = new UrlType(mainUrl + Language + "/category/worldnews/", WORLD);
                tech = new UrlType(mainUrl + Language + "/category/tech/", TECH);
                video = new UrlType(mainUrl + Language + "/category/video/", VIDEO);
                health = new UrlType(mainUrl + Language + "/category/health/", HEALTH);

                languageUrl.add(homeUrl);
                languageUrl.add(ethiopia_news);
                languageUrl.add(bussiness);
                languageUrl.add(sport);
                languageUrl.add(worldNews);
                languageUrl.add(tech);
                languageUrl.add(video);
                languageUrl.add(health);

                break;
            case English:
                homeUrl = new UrlType(mainUrl + Language, UrlType.HOME);
                ethiopia_news = new UrlType(mainUrl + Language + "/category/localnews/", NEWS);
                bussiness = new UrlType(mainUrl + Language + "/category/business/", BUSINESS);
                sport = new UrlType(mainUrl + Language + "/category/sport/", SPORT);
                worldNews = new UrlType(mainUrl + Language + "/category/worldnews/", WORLD);
                tech = new UrlType(mainUrl + Language + "/category/tech/", TECH);

                languageUrl.add(homeUrl);
                languageUrl.add(ethiopia_news);
                languageUrl.add(bussiness);
                languageUrl.add(sport);
                languageUrl.add(worldNews);
                languageUrl.add(tech);

                break;
            case AfanOromo:
                homeUrl = new UrlType(mainUrl + Language, UrlType.HOME);
                ethiopia_news = new UrlType(mainUrl + Language + "/oduu/", NEWS);
                bussiness = new UrlType(mainUrl + Language + "/buz/", BUSINESS);
                sport = new UrlType(mainUrl + Language + "/blog/category/ispoortii/", SPORT);
                worldNews = new UrlType(mainUrl + Language + "/blog/category/worldnews/", WORLD);
                tech = new UrlType(mainUrl + Language + "/blog/category/teeknooloojii/", TECH);
                health = new UrlType(mainUrl + Language+"/blog/category/fayyaa/", HEALTH);

                languageUrl.add(homeUrl);
                languageUrl.add(ethiopia_news);
                languageUrl.add(bussiness);
                languageUrl.add(sport);
                languageUrl.add(worldNews);
                languageUrl.add(tech);
                languageUrl.add(health);
                break;
            case Tigrigna:
                homeUrl = new UrlType(mainUrl + Language, UrlType.HOME);
                ethiopia_news = new UrlType(mainUrl + Language + "/%e1%8b%9c%e1%8a%93/", NEWS);
                bussiness = new UrlType(mainUrl + Language + "/%e1%89%a2%e1%8b%9d%e1%8a%90%e1%88%b5/", BUSINESS);
                sport = new UrlType(mainUrl + Language + "/blog/category/%e1%88%b5%e1%8d%93%e1%88%ad%e1%89%b5/", SPORT);
                worldNews = new UrlType(mainUrl + Language + "/blog/category/worldnews/", WORLD);
                tech = new UrlType(mainUrl + Language + "/blog/category/tech/", TECH);
                video = new UrlType(mainUrl + Language + "/blog/category/video/", VIDEO);
                health = new UrlType(mainUrl + Language + "/blog/category/health/", HEALTH);

                languageUrl.add(homeUrl);
                languageUrl.add(ethiopia_news);
                languageUrl.add(bussiness);
                languageUrl.add(sport);
                languageUrl.add(worldNews);
                languageUrl.add(tech);
                languageUrl.add(video);
                languageUrl.add(health);
        }

        return languageUrl;
    }
    public ArrayList<UrlType> getTabUrlType(){

        return new ArrayList<>(this.allUrl.subList(0, 4));
    }
}
